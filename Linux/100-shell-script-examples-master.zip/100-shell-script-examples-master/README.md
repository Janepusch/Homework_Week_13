100 shell script examples
====================================

This is archive of shell scripts that i found on the interenet long time ago. I'm not the author. Original website is located here: http://intuitive.com/wicked/wicked-cool-shell-script-library.shtml (author wrote a [book](http://intuitive.com/wicked/index.shtml)).

Besides this, you can check out these repos too:
- https://code.google.com/p/bsc/
- https://code.google.com/p/bashscripts/
- https://github.com/onlyshk/bash-snippets



Also, there is an interesting article about this that links many shell script examples:
- http://dberkholz.com/2011/04/07/bash-shell-scripting-libraries/